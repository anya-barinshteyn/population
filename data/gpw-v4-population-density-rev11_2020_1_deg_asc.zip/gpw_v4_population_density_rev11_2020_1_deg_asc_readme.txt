documentation: http://sedac.ciesin.columbia.edu/data/collection/gpw-v4/documentation

website: http://sedac.ciesin.columbia.edu/data/collection/gpw-v4/sets/browse